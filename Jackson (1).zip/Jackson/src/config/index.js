module.exports = {
    dbname: 'dcrm_stagingnew',
    hostname: 'stagingdatabasenew.cps4kisgqmqa.ap-south-1.rds.amazonaws.com',
    username: 'lms_user',
    password: '@#CP@202&*(#R',
    dialect: 'mysql'
}