module.exports = {
    user: require('./user_controller'),
    file: require('./file_controller'),
    message : require('./message_controller')
}